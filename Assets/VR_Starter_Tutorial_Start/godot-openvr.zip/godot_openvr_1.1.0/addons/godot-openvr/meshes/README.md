The resources here are taken from: `Steam\steamapps\common\SteamVR\resources\rendermodels\vr_glove\`

To save space in the repository only the slim models are included while the texture maps have been taken from the full versions.

See `../scenes/ovr_left_hand.tscn` and `../scenes/ovr_right_hand.tscn` for implementation details
